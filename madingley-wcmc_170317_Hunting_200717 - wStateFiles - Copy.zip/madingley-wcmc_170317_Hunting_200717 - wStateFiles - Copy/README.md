# C-sharp-version-of-Madingley
The most recent C# version of Madingley used by the core UNEP-WCMC development team

The required environmental data directory can be downloaded from: https://onedrive.live.com/redir?resid=3F4C6B1D2523C8D5!23908&authkey=!AN5P0wXb2hRcwy4&ithint=folder%2cnc


