﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace Madingley
{
    /// <summary>
    /// Removes individuals from animal cohorts to simulate the effects of direct harvesting
    /// </summary>
    public class Harvesting
    {

        /// Name of the file to write data on harvesting to
        /// </summary>
        string HarvestFilename = "HarvestedBiomasses";

        /// <summary>
        /// A streamwriter instance to output data on harvest
        /// </summary>
        private StreamWriter HarvestWriter;

        /// <summary>
        /// Synchronized version of the streamwriter to output harvest data
        /// </summary>
        /// 
        private TextWriter SyncHarvestWriter;



        ////////////////////////////////////////////////////////
        /// Name of the file to write data on survival probability to
        /// </summary>
        string SurvivalFilename = "SurvivalProbability";

        /// <summary>
        /// A streamwriter instance to output data on survival
        /// </summary>
        private StreamWriter SurvivalWriter;

        /// <summary>
        /// Synchronized version of the streamwriter to output survival data
        /// </summary>
        /// 
        private TextWriter SyncSurvivalWriter;
        /////////////////////////////////////////////////////


        //A class to hold the fisheries catch data for harvesting from marine cells.
        //Currently this data is from the UBC Sea around Us database
        InputCatchData FisheriesCatch;
        UtilityFunctions Utilities = new UtilityFunctions();
        ApplyFishingCatches[,] ApplyCatches;


        /// <summary>
        /// Constructor for harvesting class
        /// </summary>
        public Harvesting(string outputFileSuffix, float[] modelLats, float[] modelLons, float cellSize)
        {
            //FisheriesCatch = new InputCatchData(modelLats, modelLons,cellSize);
            //ApplyCatches = new ApplyFishingCatches[modelLats.Length,modelLons.Length];

            HarvestWriter = new StreamWriter(HarvestFilename + outputFileSuffix + " .csv");
            //create a threadsafe textwriter to write outputs to
            SyncHarvestWriter = TextWriter.Synchronized(HarvestWriter);
            SyncHarvestWriter.WriteLine("Latitude\tLongitude\ttime_step\tharvested biomass (km-2 kg-1)");

            ///////////////////////////////////////////////////////Survival
            SurvivalWriter = new StreamWriter(SurvivalFilename + outputFileSuffix + " .csv");
            //create a threadsafe textwriter to write outputs to
            SyncSurvivalWriter = TextWriter.Synchronized(SurvivalWriter);
            SyncSurvivalWriter.WriteLine("Latitude\tLongitude\ttime_step\tSurvival");
        }

        /// <summary>
        /// Remove individuals lost from cohorts through direct harvesting of animals
        /// </summary>
        /// <param name="gridCellCohorts">The cohorts in the current grid cell</param>
        /// <param name="harvestingScenario">The scenario of direct harvesting of animals to apply</param>
        /// <param name="currentTimestep">The current model time step</param>
        /// <param name="burninSteps">The number of time steps to spin the model up for before applying the harvesting scenario</param>
        /// <param name="impactSteps">The number of time steps to apply the scenario for</param>
        /// <param name="cellEnvironment">The environment in the current grid cell</param>
        /// <param name="impactCell">The index of the cell, within the list of all cells to run, to apply the scenario for</param>
        public void RemoveHarvestedIndividuals(GridCellCohortHandler gridCellCohorts,
            Tuple<string, double, double> harvestingScenario, uint currentTimestep, uint burninSteps, uint impactSteps, uint totalSteps,
            SortedList<string, double[]> cellEnvironment, Boolean impactCell, string globalModelTimestepUnits, FunctionalGroupDefinitions cohortFGs)
        {
            if (impactCell)
            {

                //If this is marine cell
                if (cellEnvironment["Realm"][0] == 2.0)
                {


                    if (harvestingScenario.Item1 == "no")
                    {
                        // Do not apply any harvesting
                    }
                    else if (harvestingScenario.Item1 == "constant")
                    {
                        double TargetBiomass;
                        if (FisheriesCatch != null)
                        {
                            TargetBiomass = (1000 *
                            FisheriesCatch.ModelGridCatchTotal[Convert.ToInt32(cellEnvironment["LatIndex"][0]), Convert.ToInt32(cellEnvironment["LonIndex"][0])])
                            / 12.0;
                        }
                        else
                        {
                            TargetBiomass = harvestingScenario.Item2;
                        }
                        // If the burn-in period has been completed, then apply
                        // the harvesting scenario
                        if (currentTimestep > burninSteps)
                        {
                            ApplyHarvesting(gridCellCohorts, TargetBiomass, cellEnvironment, currentTimestep);
                        }
                    }
                    else if (harvestingScenario.Item1 == "fish-catch")
                    {
                        //Initialise an instance of ApplyFishingCatches for this cell
                        if (currentTimestep == burninSteps)
                            ApplyCatches[Convert.ToInt32(cellEnvironment["LatIndex"][0]),
                            Convert.ToInt32(cellEnvironment["LonIndex"][0])] = new ApplyFishingCatches(FisheriesCatch);

                        if (currentTimestep > burninSteps)
                        {
                            //Bin the cohorts of the current cell
                            ApplyCatches[Convert.ToInt32(cellEnvironment["LatIndex"][0]),
                            Convert.ToInt32(cellEnvironment["LonIndex"][0])].BinCohorts(gridCellCohorts, FisheriesCatch, cohortFGs);
                            //Now remove the catch
                            ApplyCatches[Convert.ToInt32(cellEnvironment["LatIndex"][0]),
                            Convert.ToInt32(cellEnvironment["LonIndex"][0])].ApplyCatches(gridCellCohorts, FisheriesCatch,
                                Convert.ToInt32(cellEnvironment["LatIndex"][0]),
                                Convert.ToInt32(cellEnvironment["LonIndex"][0]));
                        }
                    }

                }
                else
                {
                    // non-marine

                    if (harvestingScenario.Item1 == "no")
                    {
                        // Do not apply any harvesting
                    }
                    else if (harvestingScenario.Item1 == "constant")
                    {
                        // If the burn-in period has been completed, then apply
                        // the harvesting scenario
                        if (currentTimestep > burninSteps)
                        {
                            ApplyHarvesting(gridCellCohorts, harvestingScenario.Item2, cellEnvironment, currentTimestep);
                        }
                    }
                    else if (harvestingScenario.Item1 == "temporary")
                    {
                        // If the burn-in period has been completed and the period of impact has not elapsed,
                        // then apply the harvesting scenario
                        if ((currentTimestep > burninSteps) && (currentTimestep <= (burninSteps + impactSteps)))
                        {
                            ApplyHarvesting(gridCellCohorts, harvestingScenario.Item2, cellEnvironment, currentTimestep);
                        }
                    }
                    else if (harvestingScenario.Item1 == "escalating")
                    {
                        // If the spin-up period has been completed, then apply a level of harvesting
                        // according to the number of time-steps that have elapsed since the spin-up ended
                        if (currentTimestep > burninSteps)
                        {
                            // Calculate the target biomass for harvesting based on the number of time steps that have elapsed since the spin-up
                            double TargetBiomass = (Math.Min(50000, (((currentTimestep - burninSteps) / 12.0) * harvestingScenario.Item2)));

                            // Apply the harvesting scenario using the calculated target biomass
                            ApplyHarvesting(gridCellCohorts, TargetBiomass, cellEnvironment, currentTimestep);
                        }

                    }
                    else if (harvestingScenario.Item1 == "temp-escalating-declining")
                    {
                        // If the spin-up period has been completed, then apply a level of harvesting
                        // according to the number of time-steps that have elapsed since the spin-up ended
                        if ((currentTimestep > burninSteps) && (currentTimestep <= (burninSteps + impactSteps)))
                        {
                            // Calculate the target biomass for harvesting based on the number of time steps that have elapsed since the spin-up
                            double TargetBiomass = (Math.Min(50000, (((currentTimestep - burninSteps) / 12.0) * harvestingScenario.Item2)));

                            // Apply the harvesting scenario using the calculated target biomass
                            ApplyHarvesting(gridCellCohorts, TargetBiomass, cellEnvironment, currentTimestep);
                        }
                        else if (currentTimestep > (burninSteps + impactSteps))
                        {


                            // Calculate the target biomass for harvesting based on the number of time steps that have elapsed since the spin-up
                            double TargetBiomass = (Math.Min(50000, ((-(totalSteps - currentTimestep) / 12.0) * harvestingScenario.Item2)));

                            // Apply the harvesting scenario using the calculated target biomass
                            ApplyHarvesting(gridCellCohorts, TargetBiomass, cellEnvironment, currentTimestep);
                        }

                    }
                    else if (harvestingScenario.Item1 == "temp-escalating")
                    {
                        // If the spin-up period has been completed and the period of impact has not elapsed, 
                        // then remove a proportion of plant matter
                        // according to the number of time-steps that have elapsed since the spin-up ended
                        if ((currentTimestep > burninSteps) && (currentTimestep <= (burninSteps + impactSteps)))
                        {
                            // Calculate the target biomass for harvesting based on the number of time steps that have elapsed since the spin-up
                            double TargetBiomass = (Math.Min(50000, (((currentTimestep - burninSteps) / 12.0) * harvestingScenario.Item2)));

                            // Apply the harvesting scenarion using the calculated target biomass
                            ApplyHarvesting(gridCellCohorts, TargetBiomass, cellEnvironment, currentTimestep);
                        }
                    }
                    else if (harvestingScenario.Item1 == "temp-escalating-const-rate")
                    {
                        // If the spin-up period has been completed and the period of impact (specified by the third scenario element
                        // has not elapsed, 
                        // then remove a portion of  plant matter
                        // according to the number of time-steps that have elapsed since the spin-up ended

                        int ConstImpactSteps = Convert.ToInt32(harvestingScenario.Item3 * Utilities.ConvertTimeUnits("year", globalModelTimestepUnits));

                        if ((currentTimestep > burninSteps) && (currentTimestep <= (burninSteps + ConstImpactSteps)))
                        {
                            // Calculate the target biomass for harvesting based on the number of time steps that have elapsed since the spin-up
                            double TargetBiomass = (Math.Min(200000, (((currentTimestep - burninSteps) / 12.0) * harvestingScenario.Item2)));

                            // Apply the harvesting scenarion using the calculated target biomass
                            ApplyHarvesting(gridCellCohorts, TargetBiomass, cellEnvironment, currentTimestep);
                        }
                    }
                    else if (harvestingScenario.Item1 == "temp-escalating-const-rate-duration")
                    {
                        // If the spin-up period has been completed and the period of impact (specified by the third scenario element
                        // has not elapsed, 
                        // then remove a proportion of plant matter
                        // according to the number of time-steps that have elapsed since the spin-up ended

                        int ConstImpactSteps = Convert.ToInt32(harvestingScenario.Item3 * Utilities.ConvertTimeUnits("year", globalModelTimestepUnits));

                        if ((currentTimestep > burninSteps) && (currentTimestep <= (burninSteps + impactSteps)))
                        {
                            //gridCellStocks[actingStock].TotalBiomass -= gridCellStocks[actingStock].TotalBiomass *
                            //    (Math.Min(1.0, (((currentTimestep - burninSteps) / 12.0) * humanNPPScenario.Item2)));

                            double TargetBiomass = (Math.Min(200000,
                                            Math.Min(((ConstImpactSteps / 12.0) * harvestingScenario.Item2),
                                            (((currentTimestep - burninSteps) / 12.0) * harvestingScenario.Item2))));

                            // Apply the harvesting scenarion using the calculated target biomass
                            ApplyHarvesting(gridCellCohorts, TargetBiomass, cellEnvironment, currentTimestep);
                        }
                    }
                    else if (harvestingScenario.Item1 == "constant-proportion")
                    {
                        ////////////////////////////
                        ////ANOTHER else if statement here for constant proportional harvesting
                        ////////////////////////////

                         // If the spin-up period has been completed and the period of impact (specified by the third scenario element
                        // has not elapsed, 
                        // then remove a proportion of plant matter
                        // according to the number of time-steps that have elapsed since the spin-up ended

                        int ConstImpactSteps = Convert.ToInt32(harvestingScenario.Item3 * Utilities.ConvertTimeUnits("year", globalModelTimestepUnits));

                        if ((currentTimestep > burninSteps) && (currentTimestep <= (burninSteps + impactSteps)))
                        {
                            double proportion = harvestingScenario.Item2;

                            ///New Code to harvest in one month of the year to simulate annual harvesting
                            UtilityFunctions uf = new UtilityFunctions();
                            uint month = uf.GetCurrentMonth(currentTimestep, globalModelTimestepUnits);

                            if (month == 6){
                                ApplyProportionalHarvesting(gridCellCohorts, proportion, cellEnvironment, currentTimestep, cohortFGs);
                            }

                            

                        }
                        
                    }

                    //else if (harvestingScenario.Item1 == "constant-proportion-Annual")
                    //{
                        ////////////////////////////
                        ////ANOTHER else if statement here for constant proportional harvesting
                        ////////////////////////////

                        // If the spin-up period has been completed and the period of impact (specified by the third scenario element
                        // has not elapsed, 
                        // then remove a proportion of plant matter
                        // according to the number of time-steps that have elapsed since the spin-up ended

                        //int ConstImpactSteps = Convert.ToInt32(harvestingScenario.Item3 * Utilities.ConvertTimeUnits("year", globalModelTimestepUnits));

                        //if ((currentTimestep > burninSteps) && (currentTimestep <= (burninSteps + impactSteps)))
                        //{
                          //  double proportion = harvestingScenario.Item2;
                            //ApplyProportionalHarvestingAnnual(gridCellCohorts, proportion, cellEnvironment, currentTimestep, cohortFGs);

                        //}

 //                   }





                    else
                    {
                        Debug.Fail("There is no method for the harvesting scenario specified");
                    }

                }
            }
        }

        /// <summary>
        /// Apply the results of direct harvesting of animals to the cohorts in a grid cell
        /// </summary>
        /// <param name="gridCellCohorts">The cohorts in the current grid cell</param>
        /// <param name="targetBiomass">The target biomass to be harvested</param>
        /// <param name="cellEnvironment">The environment in the current grid cell</param>
        public void ApplyHarvesting(GridCellCohortHandler gridCellCohorts, double targetBiomass,
            SortedList<string, double[]> cellEnvironment, uint currentTimestep)
        {
            // Create variable to hold total available animal biomass
            double TotalAvailableBiomass = 0.0;

            // Create tracking variable to hold total biomass times preference
            double TotalBiomassTimesPreference = 0.0;

            // Create variable to calculate the actual biomass harvested
            double TotalBiomassHarvested = 0.0;

            // Create variable to hold estimate of preference for a given cohort
            double Preference;

            // Create variable to hold the biomass of a cohort actually harvested
            double BiomassHarvested;

            //Create a variable to hold survival info
            double Survival = 0.0;

            // Create jagged arrays mirroring the cohort handler to hold calculations
            double[][] AvailableBiomass = new double[gridCellCohorts.Count][];
            double[][] BiomassTimesPreference = new double[gridCellCohorts.Count][];

            // Loop over functional groups and initialise rows in the jagged arrays
            for (int i = 0; i < gridCellCohorts.Count; i++)
            {
                AvailableBiomass[i] = new double[gridCellCohorts[i].Count];
                BiomassTimesPreference[i] = new double[gridCellCohorts[i].Count];
            }

            // Convert target biomass from kg per km squared to g per cell
            targetBiomass *= 1000; //kg to g conversion
            targetBiomass *= cellEnvironment["Cell Area"][0];

            //Add code here to set targetBiomass as a percentage//

            // Loop over cohorts and calculate available biomass and biomass times preference in each cohort, and total available biomass
            for (int fg = 0; fg < gridCellCohorts.Count; fg++)
            {
                for (int c = 0; c < gridCellCohorts[fg].Count; c++)
                {
                    TotalAvailableBiomass += (gridCellCohorts[fg][c].IndividualBodyMass * gridCellCohorts[fg][c].CohortAbundance);
                    AvailableBiomass[fg][c] = (gridCellCohorts[fg][c].IndividualBodyMass * gridCellCohorts[fg][c].CohortAbundance);
                    Preference = 1 / (1 + Math.Exp(-(-8 + 0.8 * Math.Log(gridCellCohorts[fg][c].IndividualBodyMass))));
                    //Can set Preference for Duikers ONLY?//
                    BiomassTimesPreference[fg][c] = AvailableBiomass[fg][c] * Preference;
                    TotalBiomassTimesPreference += BiomassTimesPreference[fg][c];
                }
            }

            // Loop over cohorts again, and calculate and apply the actual amount of biomass harvested
            for (int fg = 0; fg < gridCellCohorts.Count; fg++)
            {
                for (int c = 0; c < gridCellCohorts[fg].Count; c++)
                {
                    //////////////////////////////////
                    //CHECK WITH DREW: CHANGE TO THE FORMULA FOR BIOMASS HARVESTED
                    BiomassHarvested = Math.Min(AvailableBiomass[fg][c], targetBiomass * BiomassTimesPreference[fg][c] / TotalBiomassTimesPreference);
                    TotalBiomassHarvested += ((BiomassHarvested / 1000) / cellEnvironment["Cell Area"][0]);
                    ///////////////////////////////////

                    //BiomassHarvested = Math.Min(AvailableBiomass[fg][c], targetBiomass * BiomassTimesPreference[fg][c] / TotalAvailableBiomass);
                    //Don't understand this bit...why do we have targetBiomass*BiomassTimesPreference/TotalAvailableBiomass//
                    //Here, I need to have target Biomass (expressed as percentage) * Total Available Biomass for Duikers//
                    gridCellCohorts[fg][c].CohortAbundance -= (BiomassHarvested / gridCellCohorts[fg][c].IndividualBodyMass);
                }
            }

            SyncHarvestWriter.WriteLine(cellEnvironment["Latitude"][0] + "," + cellEnvironment["Longitude"][0] + "," + currentTimestep + "," + TotalBiomassHarvested);
            HarvestWriter.Flush();


            /// Survival Output
            SyncSurvivalWriter.WriteLine(cellEnvironment["Latitude"][0] + "," + cellEnvironment["Longitude"][0] + "," + currentTimestep + "," + Survival);
            SurvivalWriter.Flush();

        }

        public void ApplyProportionalHarvesting(GridCellCohortHandler gridCellCohorts, double proportion,
            SortedList<string, double[]> cellEnvironment, uint currentTimestep, FunctionalGroupDefinitions cohortFGs)
        {
            // Create variable to hold total available animal biomass
            double TotalAvailableBiomass = 0.0;

            // Create variable to calculate the actual biomass harvested
            double TotalBiomassHarvested = 0.0;

            //Create a variable to hold survival info
            double Survival = 0.0;

            // Loop over asll cohorts within the grid-cell 
            for (int fg = 0; fg < gridCellCohorts.Count; fg++)
            {
                for (int c = 0; c < gridCellCohorts[fg].Count; c++)
                {
                    // decide if this cohort is duiker-like!
                    int duikerLike = 1;
                    if (gridCellCohorts[fg][c].IndividualBodyMass>20000.0)
                    { 
                        duikerLike = 0; 
                    }

                    if (gridCellCohorts[fg][c].IndividualBodyMass < 3000.0) ////baby duiker mass; http://www.ultimateungulate.com/Artiodactyla/Cephalophus_callipygusFull.html
                    {
                        duikerLike = 0;
                    }


                    if (gridCellCohorts[fg][c].AdultMass<13000.0)
                    {
                        duikerLike = 0;
                    }
                    if (gridCellCohorts[fg][c].AdultMass>20000.0)
                    {
                        duikerLike = 0;
                    }
                    if (cohortFGs.GetTraitNames("Endo/Ectotherm", gridCellCohorts[fg][c].FunctionalGroupIndex) != "endotherm") 
                    {
                        duikerLike = 0;
                    }
                    if(cohortFGs.GetTraitNames("Nutrition source", gridCellCohorts[fg][c].FunctionalGroupIndex) != "herbivore")
                    {
                        duikerLike = 0;
                    }
                    if(duikerLike==1)
                    {
                        double AvailableBiomass = (gridCellCohorts[fg][c].IndividualBodyMass * gridCellCohorts[fg][c].CohortAbundance);
                        double BiomassHarvested = Math.Min(AvailableBiomass, AvailableBiomass * proportion);
                        TotalBiomassHarvested += ((BiomassHarvested / 1000) / cellEnvironment["Cell Area"][0]);
                        //TotalBiomassHarvested += (gridCellCohorts[fg][c].CohortAbundance / cellEnvironment["Cell Area"][0]);
                        gridCellCohorts[fg][c].CohortAbundance *= Math.Max(0.0, 1.0 - proportion);

                    }


                    ///Not yet sure what this needs to be. Cohort abundance is expressed as 'number of individuals in the cohort (per gridcell)'. we have an idea from literature about 
                    ///extinction threshold per km2. 
                    
                    ///So we need to:
                    ///1. convert abundance per grid cell to number per km2 (ie divide by grid cell area)
                    ///2. Somehow allow for other duiker-like creatures.//NOT DONE

                    double ExtinctionThreshold = 0.1;


                    if (duikerLike==1)
                    {
                        double density=gridCellCohorts[fg][c].CohortAbundance/cellEnvironment["Cell Area"][0];
                        if (density >= ExtinctionThreshold)
                            Survival = 1;
                        else
                            Survival = 0;

                    }

                    ////////////Not worked
                    //for (duikerLike=1; gridCellCohorts[fg][c].CohortAbundance >= ExtinctionThreshold; duikerLike++)
                    //{
                    //    Survival = 1;
                    //     SyncSurvivalWriter.WriteLine(cellEnvironment["Latitude"][0] + "," + cellEnvironment["Longitude"][0] + "," + currentTimestep + "," + Survival);
                    //    SurvivalWriter.Flush();
                    //}

                    //for (duikerLike = 1; gridCellCohorts[fg][c].CohortAbundance < ExtinctionThreshold; duikerLike++)
                    //{
                    //    Survival = 0;
                    //    SyncSurvivalWriter.WriteLine(cellEnvironment["Latitude"][0] + "," + cellEnvironment["Longitude"][0] + "," + currentTimestep + "," + Survival);
                    //    SurvivalWriter.Flush();
                    //}
                           
                }
            }

            SyncHarvestWriter.WriteLine(cellEnvironment["Latitude"][0] + "," + cellEnvironment["Longitude"][0] + "," + currentTimestep + "," + TotalBiomassHarvested);
            HarvestWriter.Flush();


            /// Survival Output
            SyncSurvivalWriter.WriteLine(cellEnvironment["Latitude"][0] + "," + cellEnvironment["Longitude"][0] + "," + currentTimestep + "," + Survival);
            SurvivalWriter.Flush();
        }

        public void CloseStreams()
        {
            SyncHarvestWriter.Dispose();
            HarvestWriter.Dispose();

            
        }

        public void CloseStreamsSurvive()
        {
            SyncSurvivalWriter.Dispose();
            SurvivalWriter.Dispose();


        }

    }
}
